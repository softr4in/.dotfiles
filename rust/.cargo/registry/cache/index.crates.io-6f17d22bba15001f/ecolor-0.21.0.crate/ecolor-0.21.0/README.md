# ecolor - egui color library

A simple color storage and conversion library.

Made for [`egui`](https://github.com/emilk/egui/).
