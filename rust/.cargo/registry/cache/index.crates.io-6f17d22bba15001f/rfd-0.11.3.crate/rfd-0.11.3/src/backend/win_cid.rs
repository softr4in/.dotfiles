//! Windows Common Item Dialog
//! Win32 Vista

mod utils;

mod file_dialog;
mod message_dialog;

mod thread_future;
