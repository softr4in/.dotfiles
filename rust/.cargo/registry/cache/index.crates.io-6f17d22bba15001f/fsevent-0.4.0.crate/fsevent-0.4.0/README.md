# FSEvent API for Rust

Original Author:
- Pierre Baillet @octplane

# Installation

In `cargo.toml`

```
fsevent = "*"
```

# Usage

cf examples/ folder.

# Contributors

- Mathieu Poumeyrol @kali
- ShuYu Wang @andelf
- Jake Kerr @jakerr
- Jorge Aparicio @japaric
- Markus Westerlind @Marwes
- Bruce Mitchener @waywardmonkeys
- Zac Brown @zacbrown
