# epaint - egui paint library

A bare-bones 2D graphics library for turning simple 2D shapes and text into textured triangles.

Made for [`egui`](https://github.com/emilk/egui/).
