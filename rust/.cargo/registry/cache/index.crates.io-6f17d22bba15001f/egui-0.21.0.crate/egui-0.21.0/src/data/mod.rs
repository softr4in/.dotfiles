//! All the data sent between egui and the backend

pub mod input;
pub mod output;
