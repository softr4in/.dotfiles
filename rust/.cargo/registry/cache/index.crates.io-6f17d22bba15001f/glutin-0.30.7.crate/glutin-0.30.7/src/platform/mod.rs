//! Platform-specific API helpers.

#[cfg(x11_platform)]
pub mod x11;
