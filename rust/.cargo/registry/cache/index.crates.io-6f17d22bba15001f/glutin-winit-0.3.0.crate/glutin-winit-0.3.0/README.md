# glutin-winit

The crate provides cross-platform glutin `Display` bootstrapping with winit.

This crate is also a reference on how to do the bootstrapping of glutin when
used with a cross-platform windowing library.
