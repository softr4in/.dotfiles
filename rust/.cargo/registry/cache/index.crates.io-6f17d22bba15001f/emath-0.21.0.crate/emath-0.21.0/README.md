# emath - egui math library

A bare-bones 2D math library with types and functions useful for GUI building.

Made for [`egui`](https://github.com/emilk/egui/).
